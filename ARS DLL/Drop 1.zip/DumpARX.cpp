// DumpARX.cpp: implementation of the DumpARX class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DumpARX.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#include "RecordList.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDumpARX::CDumpARX()
{
}

CDumpARX::~CDumpARX()
{
}

CDumpARX::DumpARXRecords(CARSConnection &arsConnect, CFormList &formList, CString strBackupDir)
{
	// Ensure the backup directory exists, if not create it
	CreateDirectory((LPCTSTR)strBackupDir, NULL);

	// loop once for each form, dumping each form to Backup dir
	for(int i=0; i<formList.GetSize(); i++)
	{	
		CString strFixedFormName(ReplaceFormChars(formList[i])); // working string, fixed form name
		
		// working string to hold backup file name for current form.
		CString strBackupFileName(strBackupDir); 

		// Build the finished Backup Filename
		strBackupFileName += "\\" + strFixedFormName + ".arx";
		strBackupFileName = CleanupFileName(strBackupFileName);

		// For each form, create and open a new ARX output file
		CStdioFile File(LPCSTR(strBackupFileName), 
			CFile::modeCreate | CFile::shareDenyWrite | CFile::modeWrite | CFile::typeText);

		// First, fill the record list with all entries from the form
		CRecordList recordList; // working object
		recordList.FillRecordList(arsConnect, formList[i], "", 0);
		
		// dump the list of records
		recordList.DumpARX(arsConnect, File, strFixedFormName);

		// Close the ARX file for this form
		File.Close();
	} // end for
}

///////////////////////////////////////////////////////////
// This function will return a cleaned up form name
// with all invalid characters replaced with underscores "_"
CString CDumpARX::ReplaceFormChars(CString &strFormName)
{
	CString strGoodFormName(strFormName); // working form name

	for(int i=0; i<strGoodFormName.GetLength(); i++)
	{
		if((strGoodFormName[i] >= '0' && strGoodFormName[i] <= '9') /*numbers*/
			|| (strGoodFormName[i] >= 'A' && strGoodFormName[i] <= 'Z') /*cap letters*/
			|| (strGoodFormName[i] >= 'a' && strGoodFormName[i] <= 'z') /*lower letters*/)
		{
			continue; // it's a valid character, continue to next character
		}else
		{
			// it's a bad character, convert it to underscore
			strGoodFormName.SetAt(i, '_');
		} // end if/else
	}// end for
	return strGoodFormName;
}

//DEL int CDumpARX::CreateARXFile(CString strFileName)
//DEL {
//DEL 	// Create the file
//DEL 	HANDLE hFile = CreateFile(LPCSTR(strFileName),
//DEL          GENERIC_WRITE, FILE_SHARE_READ,
//DEL          NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
//DEL 	
//DEL 	// check for errors
//DEL 	if (hFile == INVALID_HANDLE_VALUE)
//DEL 	{
//DEL       // Log the error to a log file
//DEL 	  //AfxMessageBox(_T("Couldn't create the file!"));
//DEL 	}
//DEL 
//DEL }

CString CDumpARX::CleanupFileName(CString &strFilename)
{
	while(strFilename.Replace("\\\\", "\\"))
	{
	}

	return strFilename;
}
