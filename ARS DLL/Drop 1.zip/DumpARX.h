// DumpARX.h: interface for the CDumpARX class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DUMPARX_H__705D831B_A9BD_4951_9D8D_6231EBA9F78C__INCLUDED_)
#define AFX_DUMPARX_H__705D831B_A9BD_4951_9D8D_6231EBA9F78C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ARSConnection.h"
#include "FormList.h"

class AFX_EXT_CLASS CDumpARX  
{
public:
	DumpARXRecords(CARSConnection &arsConnect, CFormList &formList, CString strBackupDir);
	CDumpARX();
	virtual ~CDumpARX();
protected:
	CString CleanupFileName(CString &strFilename);
	CString ReplaceFormChars(CString &strFormName);

};

#endif // !defined(AFX_DUMPARX_H__705D831B_A9BD_4951_9D8D_6231EBA9F78C__INCLUDED_)
