// EntryId.cpp: implementation of the CEntryId class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Record.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEntryId::CEntryId()
{
	CStringList::CStringList();
}

CEntryId::~CEntryId()
{
	CStringList::~CStringList();
}


